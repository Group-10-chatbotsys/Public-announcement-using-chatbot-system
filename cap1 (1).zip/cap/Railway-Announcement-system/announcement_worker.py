import os
import pandas as pd
from pydub import AudioSegment
from gtts import gTTS
import simpleaudio as sa

def textTospeech(text, filename):
    mytext = str(text)
    language = "hi"
    myobj = gTTS(text=mytext, lang=language, slow=True)
    myobj.save(filename)

def mergeAudios(audios):
    combined = AudioSegment.empty()
    for audio in audios:
        combined += AudioSegment.from_mp3(audio)
    return combined

def generateskeleton():
    audio = AudioSegment.from_mp3("railway.mp3")
    segments = [
        (0, 2800, "1_hindi.mp3"),      # 1-Kripiya dhyan dijiye
        (8700, 9300, "3_hindi.mp3"),   # 3-Se chalkar
        (10400, 11200, "5_hindi.mp3"), # 5-Ke raste
        (12000, 13000, "7_hindi.mp3"), # 7-Ko jane vali gadi sakhya
        (15500, 21000, "9_hindi.mp3"), # 9-Kuch hi samay mai platform sakhya
        (21500, 22500, "11_hindi.mp3") # 11-Se jayegi
    ]

    for start, finish, filename in segments:
        audioprocessed = audio[start:finish]
        audioprocessed.export(filename, format="mp3")

def generateannouncement(filename):
    df = pd.read_excel(filename)
    for index, item in df.iterrows():
        print(f"Processing announcement {index + 1}...")

        textTospeech(item["from"], "2_hindi.mp3")
        textTospeech(item["via"], "4_hindi.mp3")
        textTospeech(item["to"], "6_hindi.mp3")
        textTospeech(f"{item['train_no']} {item['train_name']}", "8_hindi.mp3")
        textTospeech(f"{item['platform']}", "10_hindi.mp3")

        audios = [f"{i}_hindi.mp3" for i in range(1, 12)]
        announcement = mergeAudios(audios)
        output_file = f"announcement_{index+1}.mp3"
        announcement.export(output_file, format="mp3")

        print(f"Playing announcement {index + 1}...")
        try:
            wave_obj = sa.WaveObject.from_wave_file(output_file)
            play_obj = wave_obj.play()
            play_obj.wait_done()
        except Exception as e:
            print(f"Error playing audio: {e}")

if __name__ == "__main__":
    from multiprocessing import Queue

    task_queue = Queue()

    print("Starting background worker...")
    generateskeleton()

    while True:
        if not task_queue.empty():
            task = task_queue.get()
            if task is None:
                print("Shutting down worker...")
                break
            generateannouncement(task)
