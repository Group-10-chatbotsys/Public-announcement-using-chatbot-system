import pandas as pd

def get_chatbot_response(message):
    """
    Process user message and return a response based on the announcements data.
    """
    file_path = "annoucment.xlsx"  # Ensure the file is uploaded

    try:
        df = pd.read_excel(file_path)
    except FileNotFoundError:
        return "Error: Announcements file not found."

    message = message.lower()

    for _, row in df.iterrows():
        train_name = row["train_name"].lower()
        train_no = str(row["train_no"]).lower()

        if train_name in message or train_no in message:
            response = (
                f"The train {row['train_name']} (Train No. {row['train_no']}) "
                f"from {row['from']} to {row['to']} via {row['via']} "
                f"is scheduled to depart from platform {row['platform']}."
            )
            return response

    return "I'm sorry, I couldn't find any information about that train."
