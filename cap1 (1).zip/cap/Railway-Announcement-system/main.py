from flask import Flask, request, jsonify, render_template
from chatbot import get_chatbot_response  # Importing chatbot functionality
import pandas as pd
import os
from pydub import AudioSegment
from gtts import gTTS
import simpleaudio as sa  # Import simpleaudio for synchronous playback

app = Flask(__name__)

# Helper Functions for Announcement
def textTospeech(text, filename):
    """
    Converts the given text to speech and saves it as an MP3 file.
    """
    mytext = str(text)
    language = "hi"
    myobj = gTTS(text=mytext, lang=language, slow=True)
    myobj.save(filename)

def mergeAudios(audios):
    """
    Merges a list of audio files into a single audio file.
    """
    combined = AudioSegment.empty()
    for audio in audios:
        combined += AudioSegment.from_mp3(audio)
    return combined

def convert_mp3_to_wav(mp3_file, wav_file):
    """
    Converts an MP3 file to WAV format.
    """
    audio = AudioSegment.from_mp3(mp3_file)
    audio.export(wav_file, format="wav")

def generateskeleton():
    """
    Generates skeleton MP3 files for fixed phrases in the announcement.
    """
    audio = AudioSegment.from_mp3("railway.mp3")
    
    # Fixed segments
    segments = {
        "1_hindi.mp3": (0, 2800),
        "3_hindi.mp3": (8700, 9300),
        "5_hindi.mp3": (10400, 11200),
        "7_hindi.mp3": (12000, 13000),
        "9_hindi.mp3": (15500, 21000),
        "11_hindi.mp3": (21500, 22500)
    }
    
    for filename, (start, finish) in segments.items():
        segment = audio[start:finish]
        segment.export(filename, format="mp3")

def generateannouncement(filename):
    """
    Reads the Excel file and generates announcements for each row of data.
    """
    df = pd.read_excel(filename)
    for index, item in df.iterrows():
        # Convert columns to speech
        textTospeech(item["from"], "2_hindi.mp3")
        textTospeech(item["via"], "4_hindi.mp3")
        textTospeech(item["to"], "6_hindi.mp3")
        textTospeech(item["train_no"] + " " + item["train_name"], "8_hindi.mp3")
        textTospeech(item["platform"], "10_hindi.mp3")

        # Merge all audio files into a single announcement
        audios = [f"{i}_hindi.mp3" for i in range(1, 12)]
        announcement = mergeAudios(audios)
        output_mp3 = f"announcement_{index+1}.mp3"
        output_wav = f"announcement_{index+1}.wav"
        announcement.export(output_mp3, format="mp3")
        
        # Convert MP3 to WAV for simpleaudio playback
        convert_mp3_to_wav(output_mp3, output_wav)

        # Play the announcement synchronously
        print(f"Playing announcement {index + 1}...")
        wave_obj = sa.WaveObject.from_wave_file(output_wav)
        play_obj = wave_obj.play()
        play_obj.wait_done()  # Wait for the current audio to finish

# Routes
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/chatbot', methods=['POST'])
def chatbot():
    """
    Handles chatbot messages and returns responses.
    """
    data = request.get_json()
    message = data.get("message", "")
    response = get_chatbot_response(message)
    return jsonify({"response": response})

@app.route('/generate_announcement', methods=['POST'])
def generate_announcement_route():
    """
    Handles file upload and generates announcements.
    """
    file = request.files.get('file')
    if not file:
        return jsonify({"error": "No file uploaded"}), 400

    filename = "uploaded_announcements.xlsx"
    file.save(filename)
    
    print("Generating Skeleton...")
    generateskeleton()
    print("Now Generating Announcement...")
    generateannouncement(filename)
    return jsonify({"response": "Announcements generated successfully!"})

if __name__ == "__main__":
    app.run(debug=True)
